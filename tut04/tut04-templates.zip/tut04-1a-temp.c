/* 
------------------------------------------------------------------------------
ALGORITHMEN & DATENSTRUKTUREN
Eric Kunze 
Github: https://github.com/oakoneric/algorithmen-datenstrukturen-ws20
Website: https://oakoneric.github.io/aud20.html
------------------------------------------------------------------------------
Aufgabe 1 a 
------------------------------------------------------------------------------
*/

#include <stdio.h>

int main() {
    
    
    printf("Das Maximum von %d und %d ist %d.\n", x, y, m);
    return 0;
}