/* 
------------------------------------------------------------------------------
ALGORITHMEN & DATENSTRUKTUREN
Eric Kunze 
Github: https://github.com/oakoneric/algorithmen-datenstrukturen-ws20
Website: https://oakoneric.github.io/aud20.html
------------------------------------------------------------------------------
Aufgabe 2 
------------------------------------------------------------------------------
*/

#include <stdio.h>

int main() {
    int matches, turn;
    int z;
    
    scanf("%d", &matches);
    turn = 1;
    
    while ( CODE ){
        if (turn == CODE){
            // Zug des Computers
            CODE
            // Bekanntgabe der verbleibenden Streichhoelzer
            CODE
        } else {
            // Zug des Menschen
            CODE
        }
    }
    
    // Bekanntgabe des Gewinners
    CODE
    
    return 0;
}
